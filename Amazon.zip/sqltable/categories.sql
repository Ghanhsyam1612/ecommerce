﻿
INSERT INTO categories (id, category_name) VALUES ('1', 'Clothes');
INSERT INTO categories (id, category_name) VALUES ('2', 'Electronics');
INSERT INTO categories (id, category_name) VALUES ('3', 'Sports');
INSERT INTO categories (id, category_name) VALUES ('4', 'Shoes');
INSERT INTO categories (id, category_name) VALUES ('5', 'Home Aplliances');
INSERT INTO categories (id, category_name) VALUES ('6', 'Cosmetics');
INSERT INTO categories (id, category_name) VALUES ('7', 'Home Decor');
